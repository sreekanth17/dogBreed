$(document).ready(function(){

});

function allDogs(){
	$('#id_showDogs').empty();
	$('#id_showDogs').hide();
	$('#id_dogsBybreed').hide();
	
	var reqUrl = "http://localhost:8090/dogs"
	$.ajax({
		  type: "GET",
		  url: reqUrl,
		  success: function(data){
		    console.log ( 'in ajax call');
		    if(data){
		    $.each(data,function(index,item){
		    	var image = $('<img></img>');
		    	var idurl = '/images/'+item.id + '/' + item.name + '.jpg';
		    	var picInfo = item.description;
		    	console.log(idurl);
		    	image.attr('src', idurl);
		    	$('#id_showDogs').append('<br>');
		    	$('#id_showDogs').append(image);
		    	$('#id_showDogs').append('<br>');
		    	$('#id_showDogs').append(picInfo);
		    	
		    	
		    });
		    }
		    $('#id_showDogs').show();
		  }
	
		});
}

function allDogsByBreed(){
	//var param = $("#id_dogBreedVal").val();
	var e = document.getElementById("id_dogBreedVal");
	var param = e.options[e.selectedIndex].text;

	$('#id_showDogs').hide();
	$('#id_dogsBybreed').empty();
	$('#id_dogsBybreed').hide();
	var reqUrl = "http://localhost:8090/dogs/" + param;
	$.ajax({
		  type: "GET",
		  url: reqUrl,
		  success: function(data){
		    console.log ( 'in ajax call');
		    if(data){
		    $.each(data,function(index,item){
		    	var image = $('<img></img>');
		    	var idurl = '/images/'+item.id + '/' + item.name + '.jpg';
		    	var picInfo = item.description;
		    	console.log(idurl);
		    	image.attr('src', idurl);
		    	$('#id_dogsBybreed').append('<br>');
		    	$('#id_dogsBybreed').append(image);
		    	$('#id_dogsBybreed').append('<br>');
		    	$('#id_dogsBybreed').append(picInfo);
		    });
		    }
		    $('#id_dogsBybreed').show();
		  }
	
		});
}