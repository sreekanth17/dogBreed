package dogbreed.springbootstarter.app;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DogBreedController {

	@Autowired
	DogBreedService dogBreedService;
	
	@RequestMapping("/dogs")
	public List<Dog> getAllDogs(){
		return dogBreedService.getAllDogs();
	}
	@RequestMapping("/dogs/{id}")
	public List<Dog> getDogsByBreed(@PathVariable String id){
		return dogBreedService.getDogsByBreed(id);
	}
}
