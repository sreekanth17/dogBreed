package dogbreed.springbootstarter.app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class DogBreedService {

	List<Dog> dogs = Arrays.asList(new Dog("German Shepherd","dogName1","dogImage1"),
			new Dog("German Shepherd","dogName2","dogImage2"),
			new Dog("German Shepherd","dogName3","dogImage3"),
			new Dog("German Shepherd","dogName4","dogImage4"),
			new Dog("Golden Retriever","dogName5","dogImage5"),
			new Dog("Golden Retriever","dogName6","dogImage6"),
			new Dog("Golden Retriever","dogName7","dogImage7"),
			new Dog("Bull","dogName8","dogImage8"),
			new Dog("Bull","dogName9","dogImage9"),
			new Dog("Bull","dogName10","dogImage10")
			);
			

	public List<Dog> getAllDogs(){
		return dogs;
	}
	
	public List<Dog> getDogsByBreed(String id){
		List<Dog> ld = new ArrayList<>();
		for(Dog d:dogs) {
			if(d.getId().equals(id)) {
				ld.add(d);
			}
		}
		return ld;
	}
}
