package dogbreed.springbootstarter.app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class DogBreedService {

	List<Dog> dogs = Arrays.asList(new Dog("German Shepherd","dogName1","Smart, confident, courageous, and steady; a true dog lover's dog."),
			new Dog("German Shepherd","dogName2","Friendly, smart, willing to please"),
			new Dog("German Shepherd","dogName3","Intelligent, determined, assertive"),
			new Dog("German Shepherd","dogName4","Naughty"),
			new Dog("Golden Retriever","dogName5","Friendly, playful, obedient at home; hardworking and steady in the field."),
			new Dog("Golden Retriever","dogName6","Enthusiastic, loyal, smart; confident but not aggressive"),
			new Dog("Golden Retriever","dogName7","Brave, Devoted, Intelligent"),
			new Dog("Bull","dogName8","Calm, courageous, and friendly; dignified but amusing."),
			new Dog("Bull","dogName9","Brave, affectionate, and loyal, the Bullmastiff will always have your back."),
			new Dog("Bull","dogName10","Playful and charming; sometimes mischievous, always loyal.")
			);
			

	public List<Dog> getAllDogs(){
		return dogs;
	}
	
	public List<Dog> getDogsByBreed(String id){
		List<Dog> ld = new ArrayList<>();
		for(Dog d:dogs) {
			if(d.getId().equals(id)) {
				ld.add(d);
			}
		}
		return ld;
	}
}
